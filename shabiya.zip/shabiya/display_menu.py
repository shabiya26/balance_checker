def menu():
    choices="""Select Your Choice
1.Deposit
2.Withdraw
3.Check Balance
"""
    print(choices)
